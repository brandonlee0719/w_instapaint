<?php 

 
defined('PHPFOX') or exit('NO DICE!'); 

?>
{template file='core.block.category'}
