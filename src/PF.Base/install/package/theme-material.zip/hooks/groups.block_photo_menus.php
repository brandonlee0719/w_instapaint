<?php

echo Phpfox::getLib('template')->getBuiltFile('core.block.actions-buttons');