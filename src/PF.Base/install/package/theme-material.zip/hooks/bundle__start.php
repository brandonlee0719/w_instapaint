<?php

$aBundleScripts[] = [
    'autoload.js' => 'flavors_material',
    'autoload.css' => 'flavors_material',
];

$aBundleScripts[] = [
    'autoload.js' => 'flavors_bootstrap',
];
