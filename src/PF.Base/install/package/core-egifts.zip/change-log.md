# eGift :: Change Log

## Version 4.6.0

### Information

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox >= 4.6.0

## Improvements

- Show popup to select eGift
- Add new block "eGifts" to show user's newest eGifts in user profile page.
- Update layout for eGift form, eGift feed.