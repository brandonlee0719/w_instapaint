<?php

$aBundleScripts[] = [
//    'autoload.css' => 'app_core-egift',
    'autoload.js' => 'app_core-egift',
];