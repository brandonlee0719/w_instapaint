<?php
$aMore = [
    "PF.Site/Apps/phpFox_Shoutbox/Ajax/Ajax.php",
    "PF.Site/Apps/phpFox_Shoutbox/assets/autoload.css",
    "PF.Site/Apps/phpFox_Shoutbox/assets/autoload.js",
    "PF.Site/Apps/phpFox_Shoutbox/assets/autoload.less",
    "PF.Site/Apps/phpFox_Shoutbox/Block/Chat.php",
    "PF.Site/Apps/phpFox_Shoutbox/hooks/core.component_controller_index_member_start.php",
    "PF.Site/Apps/phpFox_Shoutbox/hooks/groups.component_controller_view_assign.php",
    "PF.Site/Apps/phpFox_Shoutbox/hooks/pages.component_controller_view_assign.php",
    "PF.Site/Apps/phpFox_Shoutbox/hooks/template_getheader_setting.php",
    "PF.Site/Apps/phpFox_Shoutbox/icon.png",
    "PF.Site/Apps/phpFox_Shoutbox/Install.php",
    "PF.Site/Apps/phpFox_Shoutbox/Installation/Database/Shoutbox.php",
    "PF.Site/Apps/phpFox_Shoutbox/polling.php",
    "PF.Site/Apps/phpFox_Shoutbox/Service/Callback.php",
    "PF.Site/Apps/phpFox_Shoutbox/Service/Get.php",
    "PF.Site/Apps/phpFox_Shoutbox/Service/Process.php",
    "PF.Site/Apps/phpFox_Shoutbox/Service/Shoutbox.php",
    "PF.Site/Apps/phpFox_Shoutbox/start.php",
    "PF.Site/Apps/phpFox_Shoutbox/views/block/chat.html.php",
];

$aPluginFiles = array_merge($aPluginFiles, $aMore);