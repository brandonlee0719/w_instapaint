<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-shoutbox',
    'autoload.js' => 'app_core-shoutbox',
];