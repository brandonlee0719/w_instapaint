<?php
$aPhotos['photo_default_album_photo'] = [
    'title' => _p('photo_album_default_photo'),
    'value' => $flavor->default_photo('photo_default_album_photo', true),
];