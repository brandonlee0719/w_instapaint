<?php

$aBundleScripts[] = [
    'autoload.js'  => 'app_core-photos',
    'autoload.css' => 'app_core-photos',
];