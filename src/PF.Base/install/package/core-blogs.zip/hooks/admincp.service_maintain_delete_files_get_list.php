<?php
defined('PHPFOX') or exit('NO DICE!');
$aPluginFiles[] = 'PF.Base/module/blog/';
