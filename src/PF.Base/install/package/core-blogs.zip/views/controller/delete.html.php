<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
{_p var='blog_has_been_deleted'}
