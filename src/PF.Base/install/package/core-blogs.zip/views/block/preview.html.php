<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="item_content">
{$sText|parse}
</div>

<script type="text/javascript">$Core.loadInit();</script>
