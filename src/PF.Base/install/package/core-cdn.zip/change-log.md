# phpFox CDN :: Change Log

## Version 4.6.0

### Information

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox 4.6.0 or higher

### Improvements

- Check compatible with phpFox core version 4.6.0

### Changed Files

- Install.php
- Model/CDN.php
- start.php
- views/admincp.html
- views/admincp_server.html

## Version 4.5.3

### Information

- **Release Date:** August 29, 2017
- **Best Compatibility:** phpFox 4.5.3 or higher

