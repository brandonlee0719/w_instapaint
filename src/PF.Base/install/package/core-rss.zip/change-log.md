# RSS-Feeds :: Change Log

## Version 4.6.0

### Information

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox >= 4.6.0

### Improvements

- Add RSS button to the Footer menu.
- Add back button **Subscribe via RSS** in User Profile page.
- Update layout of RSS feeds listing page.