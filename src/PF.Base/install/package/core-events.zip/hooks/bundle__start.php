<?php

$aBundleScripts[] = [
//    'autoload.css' => 'app_core-events',
    'autoload.js' => 'app_core-events',
];