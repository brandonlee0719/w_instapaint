# Video

## App Info

- `App name`: Video
- `Version`: 4.6.0
- `Link on Store`: https://store.phpfox.com/product/1819/videos
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install new phpFox Video app:

1. Give 777 permission for folder **PF.Site/Apps/core-videos/**.

2. Install the Video app from the store.

3. Remove files no longer used (at Admin Panel > Maintenance > Remove files no longer used).

4. Clear cache on your site

Congratulation! You have completed installation process.