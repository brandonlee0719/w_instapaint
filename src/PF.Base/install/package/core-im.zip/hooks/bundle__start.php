<?php

$aBundleScripts[] = [
    'autoload.js'         => 'app_core-im',
    'im-libraries.min.js' => 'app_core-im',
    'autoload.css'        => 'app_core-im',
];