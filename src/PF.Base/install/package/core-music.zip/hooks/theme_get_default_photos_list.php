<?php
$aPhotos['music_default_photo'] = [
    'title' => _p('song_default_photo'),
    'value' => $flavor->default_photo('music_default_photo', true),
];
$aPhotos['music_default_album_photo'] = [
    'title' => _p('music_album_default_photo'),
    'value' => $flavor->default_photo('music_default_album_photo', true),
];