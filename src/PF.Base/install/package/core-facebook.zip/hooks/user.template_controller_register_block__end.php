<?php
echo '<div class="fb_login">';
echo '<span class="fb_login_go"><span class="ico ico-facebook-circle"></span>'. _p('sign_up_with_facebook') .'</span>';
echo '</div>';
