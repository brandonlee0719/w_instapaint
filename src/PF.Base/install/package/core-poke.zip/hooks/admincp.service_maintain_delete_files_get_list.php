<?php
$aPluginFiles[] = 'PF.Base/module/poke/';
