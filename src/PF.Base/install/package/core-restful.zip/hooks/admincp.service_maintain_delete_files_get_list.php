
 <?php
 $aPluginFiles[] = 'PF.Site/Apps/phpFox_RESTful_API';
