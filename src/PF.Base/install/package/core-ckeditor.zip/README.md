# CKEditor

## App Info

- `App name`: CKEditor
- `Version`: 4.2.0
- `Store link`: https://store.phpfox.com/product/1655/ckeditor
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## What's New in 4.2.0

- Enable setting `Allow HTML` when install app.
- Allow admin can chose CKEditor package to use on their site.
- Check compatible with phpFox core and porting apps 4.6.0.

## Installation Guide

Please follow below steps to install CKEditor app:

1. Install the CKEditor app from the store.

2. Clear cache on your site

Congratulation! You have completed installation process.