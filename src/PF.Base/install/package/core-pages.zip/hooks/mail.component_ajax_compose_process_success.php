<?php
if (!empty($sType) && $sType == 'claim-page') {
    $this->reload();
}
