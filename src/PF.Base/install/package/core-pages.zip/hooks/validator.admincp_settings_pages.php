<?php
$aValidation = [
    'pages_limit_per_category' => [
        'title' => _p('validation_pages_limit_per_category_phrase'),
        'def' => 'int:required',
        'min' => 0
    ],
];
