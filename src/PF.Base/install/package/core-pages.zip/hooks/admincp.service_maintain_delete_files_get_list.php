<?php
$aPluginFiles[] = 'PF.Base/module/pages/';
